export { default } from './AdminUpdateElectionDay';

