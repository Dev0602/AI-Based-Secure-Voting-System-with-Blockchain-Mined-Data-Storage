export { default as AddCandidate } from './AddCandidate';
export { default as AddUser } from './AddUser';
export { default as Login } from './Login';
export { default as Admin } from './Admin';
export { default as AddPromises_for_candidate } from './AddPromises_for_candidate';
export { default as Candidate_details_for_users } from './Candidate_details_for_users';
export { default as AdminUpdateElectionDay } from './AdminUpdateElectionDay';
export { default as AdminVotecount } from './AdminVotecount';