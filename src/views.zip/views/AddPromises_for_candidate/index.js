export { default } from './AddPromises_for_candidate';

