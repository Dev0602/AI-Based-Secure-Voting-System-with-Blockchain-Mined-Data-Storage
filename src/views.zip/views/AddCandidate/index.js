export { default } from './AddCandidate';

