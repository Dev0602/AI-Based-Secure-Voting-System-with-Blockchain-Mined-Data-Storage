export default {
    primary: '#637aff',
    primaryDark: '#2759ff',
    primaryLite: '#a0e2f2',
    primaryDarkBlue: 'darkblue',
    buttonPrimary:"green",
    buttonSecondary:"#ed2842"


}