export { default } from './Candidate_details_for_users';

